// GraalVM JavaScript: Read CSV file line by line using Java classes

// Use Java classes to read lines
var BufferedReader = Java.type("java.io.BufferedReader")
var FileReader = Java.type("java.io.FileReader")
var FileClass = Java.type('java.io.File');

// Path to your CSV file
var tablesAndFieldsFilePath = "TablesAndIndexFields.txt"
var result
var inputFileReader

try {
  inputFileReader = new BufferedReader(new FileReader(tablesAndFieldsFilePath))
} catch (e) {
  print( "Error: Cannot read input file\n exception message:\n" + String(e)  )
}

var headers = null
var data = []
var line = ""

// Set Output File Name
var file = new FileClass("DuplicateIds.txt")
// Obtain the FileWriter class
var FileWriterClass = Java.type('java.io.FileWriter');
// Create a FileWriter instance for new file, passing the File object
var theFilewriter = new FileWriterClass( file );

while( ( line = inputFileReader.readLine() ) !== null ) {
  line = line.trim()
  if( line === "" ) continue
  if( !headers ) {
    headers = line.split("|")
  } else {
    var values = line.split("|")

    var tableName = ""
    var fieldsInJoin = ""
    var selectQuery = ""
    for( var i = 0; i < headers.length; i++) {
      if( i === 0 && values[i] !== "" && values[i] !== undefined && values[i] !== null  ) { 
        tableName = values[i]
      } 
      if( i === 1 && values[i] !== "" && values[i] !== undefined && values[i] !== null ) {
        fieldsInJoin += "JOIN ON a." + values[i] + " = b." + values[i] + "\n"
        selectQuery = " SELECT a." + values[i] + "\n FROM " + tableName + "\n " + fieldsInJoin
      }
      if( i > 1 && values[i] !== "" && values[i] !== undefined && values[i] !== null ) {
        fieldsInJoin += " AND a." + values[i] + " = b." + values[i]  + "\n"
        selectQuery += fieldsInJoin
      }
    }
    print( "Table Name:" + tableName )
    print( "Join Instruction:" + fieldsInJoin )
    print( "Query Instruction:\n" + selectQuery + "\n" )
    theFilewriter.write("Query Instruction:\n" + selectQuery + "\n\n");
  }
}
inputFileReader.close()
theFilewriter.close();

// Wrap array in an object for JSON output
//print(JSON.stringify({ data: data }))
